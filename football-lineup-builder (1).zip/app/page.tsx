'use client';

import { useState, useRef, useEffect } from 'react';
import { FORMATIONS, FormationPosition } from './data/players';

const POSITION_COLORS = {
  GK: { bg: '#f5c518', text: '#000' },
  DEF: { bg: '#2563eb', text: '#fff' },
  MID: { bg: '#16a34a', text: '#fff' },
  FWD: { bg: '#dc2626', text: '#fff' },
};

type PosType = 'GK' | 'DEF' | 'MID' | 'FWD';

interface SlotData {
  name: string;
  pos: PosType;
  number: string;
}

interface EditModal {
  slotRole: string;
  data: SlotData;
}

const SLOT_DEFAULT_POS: Record<string, PosType> = {
  GK: 'GK',
  LB: 'DEF', RB: 'DEF', CB1: 'DEF', CB2: 'DEF', CB3: 'DEF',
  LCB: 'DEF', RCB: 'DEF', CB: 'DEF', LWB: 'DEF', RWB: 'DEF',
  LM: 'MID', RM: 'MID', LCM: 'MID', RCM: 'MID', CM: 'MID',
  DM: 'MID', LDM: 'MID', RDM: 'MID', CAM: 'MID', LAM: 'MID', RAM: 'MID',
  LW: 'FWD', RW: 'FWD', ST: 'FWD', LST: 'FWD', RST: 'FWD',
};

function PitchSlot({
  slot,
  data,
  onClick,
  onRemove,
  isDragOver,
  onDragOver,
  onDragLeave,
  onDrop,
  onDragStart,
}: {
  slot: FormationPosition;
  data?: SlotData;
  onClick: () => void;
  onRemove: () => void;
  isDragOver: boolean;
  onDragOver: (e: React.DragEvent) => void;
  onDragLeave: () => void;
  onDrop: (e: React.DragEvent) => void;
  onDragStart: (e: React.DragEvent) => void;
}) {
  const colors = data ? POSITION_COLORS[data.pos] : { bg: 'rgba(255,255,255,0.15)', text: '#fff' };

  return (
    <div
      style={{
        position: 'absolute',
        left: `${slot.x}%`,
        top: `${slot.y}%`,
        transform: 'translate(-50%, -50%)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 3,
        zIndex: 10,
      }}
      onDragOver={e => { e.preventDefault(); onDragOver(e); }}
      onDrop={onDrop}
      onDragLeave={onDragLeave}
    >
      {/* Circle */}
      <div
        draggable={!!data}
        onDragStart={onDragStart}
        onClick={onClick}
        style={{
          width: 62,
          height: 62,
          borderRadius: '50%',
          cursor: 'pointer',
          background: data
            ? `linear-gradient(135deg, ${colors.bg}dd, ${colors.bg}99)`
            : isDragOver
            ? 'rgba(0,255,135,0.2)'
            : 'rgba(255,255,255,0.06)',
          border: isDragOver
            ? '2.5px dashed #00ff87'
            : data
            ? `3px solid ${colors.bg}`
            : '2px dashed rgba(255,255,255,0.25)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          transition: 'all 0.15s',
          boxShadow: data ? `0 4px 20px ${colors.bg}44` : 'none',
          userSelect: 'none',
        }}
      >
        {data ? (
          <>
            <span style={{ fontSize: 9, fontWeight: 700, color: colors.text, opacity: 0.8, lineHeight: 1 }}>
              {data.number ? `#${data.number}` : data.pos}
            </span>
            <span style={{ fontSize: 13, fontWeight: 800, color: colors.text, lineHeight: 1.1, textAlign: 'center', padding: '0 4px', maxWidth: 56, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {data.name.split(' ').slice(-1)[0]}
            </span>
          </>
        ) : (
          <span style={{ fontSize: 18, color: 'rgba(255,255,255,0.2)' }}>+</span>
        )}
      </div>

      {/* Name tag */}
      {data ? (
        <div style={{
          background: 'rgba(0,0,0,0.82)',
          backdropFilter: 'blur(6px)',
          border: `1px solid ${colors.bg}55`,
          borderRadius: 5,
          padding: '2px 6px',
          display: 'flex',
          alignItems: 'center',
          gap: 3,
          maxWidth: 112,
        }}>
          <span style={{ fontSize: 8, background: colors.bg, color: colors.text, borderRadius: 3, padding: '1px 3px', fontWeight: 700, flexShrink: 0 }}>
            {slot.label}
          </span>
          <span style={{ fontSize: 10, color: '#f0f6fc', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', fontWeight: 600 }}>
            {data.name}
          </span>
          <button
            onClick={e => { e.stopPropagation(); onRemove(); }}
            style={{ background: 'none', border: 'none', color: '#ff4444', cursor: 'pointer', fontSize: 11, padding: 0, lineHeight: 1, flexShrink: 0 }}
          >×</button>
        </div>
      ) : (
        <div style={{
          background: 'rgba(0,0,0,0.4)',
          borderRadius: 3,
          padding: '1px 5px',
          fontSize: 9,
          color: isDragOver ? '#00ff87' : 'rgba(255,255,255,0.3)',
          fontWeight: 600,
        }}>
          {isDragOver ? 'Bırak' : slot.label}
        </div>
      )}
    </div>
  );
}

function PlayerModal({
  slotLabel,
  defaultPos,
  initial,
  onSave,
  onClose,
}: {
  slotLabel: string;
  defaultPos: PosType;
  initial?: SlotData;
  onSave: (data: SlotData) => void;
  onClose: () => void;
}) {
  const [name, setName] = useState(initial?.name || '');
  const [pos, setPos] = useState<PosType>(initial?.pos || defaultPos);
  const [number, setNumber] = useState(initial?.number || '');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setTimeout(() => inputRef.current?.focus(), 50);
  }, []);

  const handleSave = () => {
    if (!name.trim()) return;
    onSave({ name: name.trim(), pos, number: number.trim() });
  };

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 1000,
      background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }} onClick={onClose}>
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: '#161b22',
          border: '1px solid #30363d',
          borderRadius: 14,
          padding: 28,
          width: 340,
          boxShadow: '0 20px 60px rgba(0,0,0,0.6)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
          <div>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#f0f6fc' }}>
              {initial ? 'Oyuncuyu Düzenle' : 'Oyuncu Ekle'}
            </div>
            <div style={{ fontSize: 11, color: '#8b949e', marginTop: 2 }}>
              Pozisyon: <span style={{ color: '#00ff87', fontWeight: 600 }}>{slotLabel}</span>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#8b949e', cursor: 'pointer', fontSize: 20, lineHeight: 1 }}>×</button>
        </div>

        {/* Name input */}
        <div style={{ marginBottom: 14 }}>
          <label style={{ fontSize: 11, fontWeight: 600, color: '#8b949e', display: 'block', marginBottom: 6 }}>OYUNCU ADI</label>
          <input
            ref={inputRef}
            value={name}
            onChange={e => setName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSave()}
            placeholder="Örn: Lionel Messi"
            style={{
              width: '100%', background: '#21262d', border: '1px solid #30363d',
              borderRadius: 8, padding: '10px 12px', color: '#f0f6fc', fontSize: 14,
              fontWeight: 600, outline: 'none', boxSizing: 'border-box',
              transition: 'border-color 0.15s',
            }}
            onFocus={e => (e.target.style.borderColor = '#00ff87')}
            onBlur={e => (e.target.style.borderColor = '#30363d')}
          />
        </div>

        {/* Forma numarası */}
        <div style={{ marginBottom: 14 }}>
          <label style={{ fontSize: 11, fontWeight: 600, color: '#8b949e', display: 'block', marginBottom: 6 }}>FORMA NUMARASI (opsiyonel)</label>
          <input
            value={number}
            onChange={e => setNumber(e.target.value.replace(/\D/g, '').slice(0, 2))}
            onKeyDown={e => e.key === 'Enter' && handleSave()}
            placeholder="10"
            style={{
              width: '100%', background: '#21262d', border: '1px solid #30363d',
              borderRadius: 8, padding: '10px 12px', color: '#f0f6fc', fontSize: 14,
              fontWeight: 600, outline: 'none', boxSizing: 'border-box',
            }}
            onFocus={e => (e.target.style.borderColor = '#00ff87')}
            onBlur={e => (e.target.style.borderColor = '#30363d')}
          />
        </div>

        {/* Position selector */}
        <div style={{ marginBottom: 22 }}>
          <label style={{ fontSize: 11, fontWeight: 600, color: '#8b949e', display: 'block', marginBottom: 6 }}>POZİSYON</label>
          <div style={{ display: 'flex', gap: 6 }}>
            {(['GK', 'DEF', 'MID', 'FWD'] as PosType[]).map(p => {
              const c = POSITION_COLORS[p];
              return (
                <button
                  key={p}
                  onClick={() => setPos(p)}
                  style={{
                    flex: 1, padding: '8px 0', borderRadius: 7, border: 'none', cursor: 'pointer',
                    background: pos === p ? c.bg : '#21262d',
                    color: pos === p ? c.text : '#8b949e',
                    fontSize: 12, fontWeight: 700, transition: 'all 0.15s',
                  }}
                >
                  {p}
                </button>
              );
            })}
          </div>
        </div>

        {/* Buttons */}
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            onClick={onClose}
            style={{ flex: 1, padding: '10px', background: '#21262d', border: '1px solid #30363d', borderRadius: 8, color: '#8b949e', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}
          >
            İptal
          </button>
          <button
            onClick={handleSave}
            disabled={!name.trim()}
            style={{
              flex: 2, padding: '10px', background: name.trim() ? '#00ff87' : '#21262d',
              border: 'none', borderRadius: 8, color: name.trim() ? '#000' : '#8b949e',
              fontSize: 13, fontWeight: 700, cursor: name.trim() ? 'pointer' : 'not-allowed',
              transition: 'all 0.15s',
            }}
          >
            {initial ? '✓ Güncelle' : '+ Ekle'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function LineupBuilder() {
  const [formation, setFormation] = useState('4-3-3');
  const [lineup, setLineup] = useState<Record<string, SlotData>>({});
  const [modal, setModal] = useState<EditModal | null>(null);
  const [dragOver, setDragOver] = useState<string | null>(null);
  const [dragging, setDragging] = useState<{ slotRole: string; data: SlotData } | null>(null);
  const [teamName, setTeamName] = useState('Takımım');
  const [sidebarTab, setSidebarTab] = useState<'kadro' | 'istatistik'>('kadro');

  const currentFormation = FORMATIONS[formation];
  const filledCount = Object.keys(lineup).length;
  const totalSlots = currentFormation.positions.length;

  const handleFormationChange = (f: string) => {
    const newSlots = FORMATIONS[f].positions.map(p => p.role);
    const oldSlots = currentFormation.positions;
    const newLineup: Record<string, SlotData> = {};
    newSlots.forEach((role, i) => {
      const old = oldSlots[i];
      if (old && lineup[old.role]) newLineup[role] = lineup[old.role];
    });
    setLineup(newLineup);
    setFormation(f);
  };

  const openModal = (slotRole: string) => {
    setModal({ slotRole, data: lineup[slotRole] || { name: '', pos: SLOT_DEFAULT_POS[slotRole] || 'MID', number: '' } });
  };

  const handleSave = (data: SlotData) => {
    if (!modal) return;
    setLineup(prev => ({ ...prev, [modal.slotRole]: data }));
    setModal(null);
  };

  const removeFromSlot = (slotRole: string) => {
    setLineup(prev => { const n = { ...prev }; delete n[slotRole]; return n; });
  };

  const clearAll = () => setLineup({});

  const handleDragStart = (e: React.DragEvent, slotRole: string) => {
    const data = lineup[slotRole];
    if (!data) return;
    e.dataTransfer.effectAllowed = 'move';
    setDragging({ slotRole, data });
  };

  const handleDrop = (e: React.DragEvent, targetSlot: string) => {
    e.preventDefault();
    setDragOver(null);
    if (!dragging) return;
    const { slotRole: sourceSlot, data } = dragging;
    setLineup(prev => {
      const next = { ...prev };
      const existingAtTarget = next[targetSlot];
      if (existingAtTarget) next[sourceSlot] = existingAtTarget;
      else delete next[sourceSlot];
      next[targetSlot] = data;
      return next;
    });
    setDragging(null);
  };

  const posCounts = (['GK', 'DEF', 'MID', 'FWD'] as PosType[]).map(pos => ({
    pos,
    count: Object.values(lineup).filter(p => p.pos === pos).length,
  }));

  const posSlotCounts: Record<string, string[]> = {
    GK: ['GK'], DEF: ['LB','CB1','CB2','CB3','RB','LCB','RCB','CB','LWB','RWB'],
    MID: ['LM','RM','LCM','RCM','CM','DM','LDM','RDM','CAM','LAM','RAM'],
    FWD: ['LW','RW','ST','LST','RST'],
  };

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden', background: '#0d1117', fontFamily: "'Inter', sans-serif", color: '#f0f6fc' }}>

      {/* MODAL */}
      {modal && (
        <PlayerModal
          slotLabel={currentFormation.positions.find(p => p.role === modal.slotRole)?.label || modal.slotRole}
          defaultPos={SLOT_DEFAULT_POS[modal.slotRole] || 'MID'}
          initial={modal.data.name ? modal.data : undefined}
          onSave={handleSave}
          onClose={() => setModal(null)}
        />
      )}

      {/* LEFT SIDEBAR */}
      <div style={{ width: 260, background: '#161b22', borderRight: '1px solid #30363d', display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
        {/* Header */}
        <div style={{ padding: '14px 16px 12px', borderBottom: '1px solid #30363d' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
            <div style={{ width: 38, height: 38, background: 'linear-gradient(135deg, #00ff87, #00cc6e)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, boxShadow: '0 4px 12px rgba(0,255,135,0.3)' }}>⚽</div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 800, color: '#f0f6fc', letterSpacing: 1.5 }}>LINEUP BUILDER</div>
              <div style={{ fontSize: 10, color: '#8b949e' }}>Kendi kadronuzu oluşturun</div>
            </div>
          </div>

          {/* Takım adı */}
          <div style={{ marginBottom: 10 }}>
            <label style={{ fontSize: 10, fontWeight: 600, color: '#8b949e', display: 'block', marginBottom: 5 }}>TAKIM ADI</label>
            <input
              value={teamName}
              onChange={e => setTeamName(e.target.value)}
              placeholder="Takım adı..."
              style={{ width: '100%', background: '#21262d', border: '1px solid #30363d', borderRadius: 6, padding: '7px 10px', color: '#f0f6fc', fontSize: 13, fontWeight: 600, outline: 'none', boxSizing: 'border-box' }}
              onFocus={e => (e.target.style.borderColor = '#00ff87')}
              onBlur={e => (e.target.style.borderColor = '#30363d')}
            />
          </div>

          {/* Formation */}
          <div style={{ marginBottom: 12 }}>
            <label style={{ fontSize: 10, fontWeight: 600, color: '#8b949e', display: 'block', marginBottom: 5 }}>FORMASYON</label>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 4 }}>
              {Object.keys(FORMATIONS).map(f => (
                <button key={f} onClick={() => handleFormationChange(f)} style={{ background: formation === f ? '#00ff87' : '#21262d', color: formation === f ? '#000' : '#8b949e', border: 'none', borderRadius: 5, padding: '5px 2px', fontSize: 10, fontWeight: 700, cursor: 'pointer', transition: 'all 0.15s' }}>
                  {f}
                </button>
              ))}
            </div>
          </div>

          {/* Stats */}
          <div style={{ display: 'flex', gap: 5 }}>
            {[
              { v: filledCount, label: 'DOLU', color: '#00ff87' },
              { v: totalSlots - filledCount, label: 'BOŞ', color: '#f0f6fc' },
              { v: `${Math.round((filledCount / totalSlots) * 100)}%`, label: 'TAMAMLANDI', color: '#f0b429' },
            ].map(s => (
              <div key={s.label} style={{ flex: 1, background: '#21262d', borderRadius: 6, padding: '6px 4px', textAlign: 'center' }}>
                <div style={{ fontSize: 15, fontWeight: 700, color: s.color }}>{s.v}</div>
                <div style={{ fontSize: 8, color: '#8b949e' }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', borderBottom: '1px solid #30363d' }}>
          {(['kadro', 'istatistik'] as const).map(tab => (
            <button key={tab} onClick={() => setSidebarTab(tab)} style={{ flex: 1, padding: '9px', background: 'none', border: 'none', color: sidebarTab === tab ? '#00ff87' : '#8b949e', fontSize: 11, fontWeight: 700, cursor: 'pointer', textTransform: 'uppercase', borderBottom: sidebarTab === tab ? '2px solid #00ff87' : '2px solid transparent', transition: 'all 0.15s' }}>
              {tab === 'kadro' ? 'Kadro' : 'İstatistik'}
            </button>
          ))}
        </div>

        {sidebarTab === 'kadro' && (
          <div style={{ flex: 1, overflowY: 'auto', padding: 8 }}>
            {currentFormation.positions.map(slot => {
              const p = lineup[slot.role];
              const c = p ? POSITION_COLORS[p.pos] : { bg: '#30363d', text: '#8b949e' };
              return (
                <div
                  key={slot.role}
                  onClick={() => openModal(slot.role)}
                  style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 8px', borderRadius: 7, marginBottom: 3, cursor: 'pointer', background: p ? '#21262d' : '#191f27', border: `1px solid ${p ? c.bg + '44' : '#30363d'}`, transition: 'background 0.12s' }}
                  onMouseEnter={e => (e.currentTarget.style.background = p ? '#2a3441' : '#21262d')}
                  onMouseLeave={e => (e.currentTarget.style.background = p ? '#21262d' : '#191f27')}
                >
                  {/* Avatar circle */}
                  <div style={{ width: 32, height: 32, borderRadius: '50%', background: c.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <span style={{ fontSize: p ? 11 : 16, fontWeight: 700, color: p ? c.text : '#8b949e' }}>
                      {p ? (p.name.split(' ').map((w: string) => w[0]).join('').slice(0, 2)) : '+'}
                    </span>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    {p ? (
                      <>
                        <div style={{ fontSize: 12, fontWeight: 600, color: '#f0f6fc', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.name}</div>
                        <div style={{ fontSize: 10, color: '#8b949e' }}>{p.number ? `#${p.number} · ` : ''}{p.pos}</div>
                      </>
                    ) : (
                      <div style={{ fontSize: 11, color: '#8b949e', fontStyle: 'italic' }}>Oyuncu ekle...</div>
                    )}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, flexShrink: 0 }}>
                    <span style={{ fontSize: 8, background: '#30363d', color: '#8b949e', padding: '1px 4px', borderRadius: 3, fontWeight: 700 }}>{slot.label}</span>
                    {p && (
                      <button onClick={e => { e.stopPropagation(); removeFromSlot(slot.role); }} style={{ background: 'none', border: 'none', color: '#ff4444', cursor: 'pointer', fontSize: 14, padding: '0 2px', lineHeight: 1 }}>×</button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {sidebarTab === 'istatistik' && (
          <div style={{ flex: 1, overflowY: 'auto', padding: '14px 12px' }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: '#8b949e', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 14 }}>Pozisyon Dağılımı</div>
            {(['GK', 'DEF', 'MID', 'FWD'] as PosType[]).map(pos => {
              const count = Object.values(lineup).filter(p => p.pos === pos).length;
              const slots = currentFormation.positions.filter(s => posSlotCounts[pos]?.includes(s.role)).length;
              const colors = POSITION_COLORS[pos];
              return (
                <div key={pos} style={{ marginBottom: 14 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                    <span style={{ fontSize: 12, fontWeight: 700, color: colors.bg }}>{pos}</span>
                    <span style={{ fontSize: 12, color: '#8b949e' }}>{count}/{slots}</span>
                  </div>
                  <div style={{ height: 5, background: '#21262d', borderRadius: 3 }}>
                    <div style={{ height: '100%', width: slots > 0 ? `${(count / slots) * 100}%` : '0%', background: colors.bg, borderRadius: 3, transition: 'width 0.3s' }} />
                  </div>
                </div>
              );
            })}

            <div style={{ marginTop: 20 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#8b949e', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10 }}>İlerleme</div>
              <div style={{ background: '#21262d', borderRadius: 10, padding: 14, textAlign: 'center' }}>
                <div style={{ fontSize: 32, fontWeight: 800, color: filledCount === totalSlots ? '#00ff87' : '#f0f6fc', marginBottom: 4 }}>
                  {Math.round((filledCount / totalSlots) * 100)}%
                </div>
                <div style={{ fontSize: 11, color: '#8b949e' }}>
                  {filledCount}/{totalSlots} slot dolu
                </div>
                {filledCount === totalSlots && (
                  <div style={{ marginTop: 8, fontSize: 12, color: '#00ff87', fontWeight: 600 }}>✓ Kadro tamamlandı!</div>
                )}
              </div>
            </div>

            {filledCount > 0 && (
              <div style={{ marginTop: 16 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: '#8b949e', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10 }}>Oyuncular</div>
                {Object.entries(lineup).map(([role, p]) => {
                  const slot = currentFormation.positions.find(s => s.role === role);
                  const c = POSITION_COLORS[p.pos];
                  return (
                    <div key={role} style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 7 }}>
                      <div style={{ width: 26, height: 26, borderRadius: '50%', background: c.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <span style={{ fontSize: 9, fontWeight: 800, color: c.text }}>{p.name.split(' ').map((w:string)=>w[0]).join('').slice(0,2)}</span>
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 11, fontWeight: 600, color: '#f0f6fc', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.name}</div>
                        {p.number && <div style={{ fontSize: 9, color: '#8b949e' }}>#{p.number}</div>}
                      </div>
                      <span style={{ fontSize: 8, background: c.bg, color: c.text, padding: '2px 4px', borderRadius: 3, fontWeight: 700, flexShrink: 0 }}>
                        {slot?.label || p.pos}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* MAIN PITCH */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Top bar */}
        <div style={{ padding: '12px 20px', borderBottom: '1px solid #30363d', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: '#161b22' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <h1 style={{ fontSize: 22, fontWeight: 800, color: '#f0f6fc', letterSpacing: 2 }}>{teamName.toUpperCase()}</h1>
            <span style={{ background: '#21262d', color: '#00ff87', padding: '3px 10px', borderRadius: 20, fontSize: 12, fontWeight: 700, border: '1px solid #00ff8733' }}>{formation}</span>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={clearAll} style={{ background: '#21262d', border: '1px solid #30363d', color: '#ff4444', padding: '7px 14px', borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>🗑 Temizle</button>
          </div>
        </div>

        {/* Pitch area */}
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16, overflow: 'hidden' }}>
          <div style={{ position: 'relative', width: '100%', maxWidth: 580, aspectRatio: '0.68', maxHeight: 'calc(100vh - 112px)', borderRadius: 8, overflow: 'hidden' }}>
            {/* Grass */}
            <div style={{ position: 'absolute', inset: 0, background: 'repeating-linear-gradient(0deg, #1a4a1a 0px, #1a4a1a 36px, #1d5520 36px, #1d5520 72px)' }} />
            {/* Lines */}
            <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} viewBox="0 0 100 147" preserveAspectRatio="none">
              <rect x="4" y="3" width="92" height="141" fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth="0.5" />
              <line x1="4" y1="73.5" x2="96" y2="73.5" stroke="rgba(255,255,255,0.5)" strokeWidth="0.4" />
              <circle cx="50" cy="73.5" r="11" fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth="0.4" />
              <circle cx="50" cy="73.5" r="0.8" fill="rgba(255,255,255,0.5)" />
              <rect x="20" y="3" width="60" height="22" fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth="0.4" />
              <rect x="34" y="3" width="32" height="9" fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth="0.4" />
              <circle cx="50" cy="18" r="0.7" fill="rgba(255,255,255,0.5)" />
              <rect x="20" y="122" width="60" height="22" fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth="0.4" />
              <rect x="34" y="135" width="32" height="9" fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth="0.4" />
              <circle cx="50" cy="129" r="0.7" fill="rgba(255,255,255,0.5)" />
              <rect x="38" y="1" width="24" height="2.5" fill="rgba(255,255,255,0.15)" stroke="rgba(255,255,255,0.5)" strokeWidth="0.3" />
              <rect x="38" y="143.5" width="24" height="2.5" fill="rgba(255,255,255,0.15)" stroke="rgba(255,255,255,0.5)" strokeWidth="0.3" />
            </svg>

            {/* Slots */}
            {currentFormation.positions.map(slot => (
              <PitchSlot
                key={slot.role}
                slot={slot}
                data={lineup[slot.role]}
                onClick={() => openModal(slot.role)}
                onRemove={() => removeFromSlot(slot.role)}
                isDragOver={dragOver === slot.role}
                onDragOver={() => setDragOver(slot.role)}
                onDragLeave={() => setDragOver(null)}
                onDrop={e => handleDrop(e, slot.role)}
                onDragStart={e => handleDragStart(e, slot.role)}
              />
            ))}

            {/* Watermarks */}
            <div style={{ position: 'absolute', bottom: 7, right: 10, fontSize: 11, color: 'rgba(255,255,255,0.12)', letterSpacing: 2 }}>{formation}</div>
            <div style={{ position: 'absolute', top: 7, left: 0, right: 0, textAlign: 'center', fontSize: 13, color: 'rgba(255,255,255,0.12)', letterSpacing: 3 }}>{teamName.toUpperCase()}</div>

            {/* Empty state hint */}
            {filledCount === 0 && (
              <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
                <div style={{ background: 'rgba(0,0,0,0.55)', borderRadius: 12, padding: '16px 22px', textAlign: 'center', backdropFilter: 'blur(4px)' }}>
                  <div style={{ fontSize: 28, marginBottom: 6 }}>👆</div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: '#f0f6fc', marginBottom: 3 }}>Oyuncu eklemek için tıkla</div>
                  <div style={{ fontSize: 11, color: '#8b949e' }}>veya sol panelden slot seç</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
